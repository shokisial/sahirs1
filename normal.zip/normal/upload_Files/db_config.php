<?php
	$dbHost = "localhost";
	$dbDatabase = "v0503sah_saestatedb";
	$dbPasswrod = "rev$X,#zm9hlG1~;=P";
	$dbUser = "v0503sah_newusr";
	$mysqli = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
?>