<?php
    header("refresh: 30;");
?>