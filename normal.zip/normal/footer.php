<div class="pull-right">
		<footer>
           <p>Sahir Associates (Pvt) Ltd</p>
        <footer>
</div>