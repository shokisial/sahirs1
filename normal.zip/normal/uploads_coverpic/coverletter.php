<p>
    <strong><u></u></strong>
</p>
<p>
    <strong><u></u></strong>
</p>

<p align="center">
    <H1 align="center"><u>Covering Letter</u></H1>
</p>
<p>
    Number of Transfer: 1
</p>
<table cellpadding="30"  width="50%" align="center">
    <tbody>
        <tr>
            <td>
                <div>
                    <img src="../uploads_coverpic/sonali-musjid.jpg" align="center" width="500" height="400">
                </div>
            </td>
        </tr>
    </tbody>
</table>

<br clear="ALL"/>
<table align="right" width="100%">
    <tbody>
        <tr>
            <td>
                
                    <p align="right">
                        BM Signatures                                  
                    </p>
                
            </td>
        </tr>
    </tbody>
</table>
<br clear="ALL"/>
<br>
<br>
<p align="right">
    Seen By: __________________________
</p>
<p align="right">
    Transfer Officer
</p>
<p align="right">
    Name of BM
</p>
<p>
    <strong>Allotment No:</strong>
    <u> </u>
    Plot # <u> </u> Block <u> </u> <em></em>
</p>
<p>
    <strong>Plot Size:</strong>
    <u> </u>
    <strong>Category:</strong>
    <u> </u>
</p>
<p>
    <strong>Transfer the Plot on:</strong>
    <u>Transfer Date (DD/MM/YYY)</u>
</p>
<p>
    <strong>Transferor: </strong>
    <u> </u>
    S/O,D/O,W/O <u> </u>
</p>
<p>
    <strong>Transferee: </strong>
    <u> </u>
    S/O,D/O,W/O <u> </u>
</p>

<p align="center">
<img src="../uploads_coverpic/sahirsdownlogo.png" align="center" width="400" height="100>"> </p>