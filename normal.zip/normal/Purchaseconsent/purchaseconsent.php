<p style="text-align: center;"><strong><u>Purchase Consent</u></strong></p>
<p>&nbsp;</p>
<p style="text-align: justify;">I, <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </u>S/O,D/O,W/O <u> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</u>&nbsp;bearing CNIC <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </u>&nbsp;has purchased Plot #<u>&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </u> Block <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </u>of Khayaban-e-Amin, and has received the allotment letter for the same. I undertake:</p>
<ol style="text-align: justify;">
<li>That I abide by the schedule of payment as received</li>
<li>Payment shall be made through cash/banking instrument if favor of M/s Sahir Associates (Pvt) Ltd.</li>
<li>Installment received from the Applicant/Allotee after due date shall only be accepted with a surcharge of 20% per annum for the period of default (calculated on daily basis) up to 15 days from the due date.</li>
<li>In case default in payment is continued for more than 15 days, the company shall have the right to cancel the allotment and allot/sell the same to any other person and the defaulter shall have no right or lien whatsoever to such a plot except for the refund of the amount paid after 10% deduction of total cost of the plot less down payment.</li>
<li>If the applicant wants to resume with a cancelled allotment, he/she needs to pay activation fee PKR 100,000/- at every cancellation.</li>
<li>Any factor amount if applicable, would be charged at the time of possession.</li>
<li>The applicant and the successor are bound to clear the accounts of developmental if applied at any point.</li>
<li>The decision of the company in respect of allotment /cancellation shall be final and binding on the applicant/allotee and shall not be challenged before any court of law, forum or authority.</li>
<li>Plot allotted shall not be used for any other purpose except for the purpose as specified in the bye-laws.</li>
<li>The company reserves the right to make adjustments / relocation of the plot if need arises. This would be done only when the ground situation imposes any unavoidable limitations.</li>
<li>In case of any dispute arising between the Allotee and the Company / Association/Project Management, Estate Management or any of their officer, the dispute shall be referred to the arbitration of Chief Executive of M/s Sahir Associates (Pvt.) Ltd. Whose decision Shall be final and binding on the parties.</li>
</ol>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Deponent&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>DEPONENT</u>&nbsp; </strong></p>
<p style="text-align: justify;"><strong><u>VERIFICATION:- </u></strong></p>
<p style="text-align: justify;">Verified on oath this _______________________ day of _________________ that content of the above affidavit are true and correct to the best of my knowledge and belief and that nothing has been concealed there in.</p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;"><strong><u>DEPONENT&nbsp;&nbsp; </u></strong></p>
<p style="text-align: justify;">&nbsp;</p>